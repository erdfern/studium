color1 = "gold"
color2 = "indigo"
custom_cmap = "inferno"
