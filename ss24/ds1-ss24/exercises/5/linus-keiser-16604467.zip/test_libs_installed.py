def test_libs_installed():
    import pandas
    import numpy
    import matplotlib
    import seaborn
